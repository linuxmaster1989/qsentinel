import re
import os
from collections import Counter

# v1.8 Direct Access Paths - Standard Ubuntu & aaPanel locations
DIRECT_SYSTEM_PATHS = {
    "auth": "/var/log/auth.log",
    "aapanel": "/www/wwwlogs/access.log" 
}

def extract_all_unauthorized_attempts(file_path):
    all_names = []
    # v1.8 Logic: If the file isn't in the local folder, check the system path
    target = file_path
    if not os.path.exists(file_path) and file_path == "auth.log":
        target = DIRECT_SYSTEM_PATHS["auth"]

    pattern = re.compile(r"(?:Invalid user|Failed password for(?: invalid user)?) ([^\s]+) from")
    
    try:
        with open(target, 'r') as f:
            for line in f:
                match = pattern.search(line)
                if match:
                    all_names.append(match.group(1).strip())
    except (FileNotFoundError, PermissionError) as e:
        print(f"[!] Access Error on {target}: {e}")
        return None
    return all_names

def extract_aapanel_access_data(file_path):
    access_signatures = []
    # v1.8 Logic: Check local folder first, then default aaPanel Nginx path
    target = file_path
    if not os.path.exists(file_path) and file_path == "access.log":
        target = DIRECT_SYSTEM_PATHS["aapanel"]

    pattern = re.compile(r'(\d+\.\d+\.\d+\.\d+) - - .*?"\w+ (.*?) HTTP/.*?" (\d+)')
    
    try:
        with open(target, 'r') as f:
            for line in f:
                match = pattern.search(line)
                if match:
                    ip, path, status = match.groups()
                    # Focus on 4xx errors (client errors/scanning)
                    if status.startswith('4'):
                        access_signatures.append(path)
    except (FileNotFoundError, PermissionError) as e:
        print(f"[!] Access Error on {target}: {e}")
        return None
    return access_signatures
    