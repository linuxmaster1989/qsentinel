import questionary
import os
import sys
import json
import hashlib
from datetime import datetime
from collections import Counter
from log_parser import extract_all_unauthorized_attempts, extract_aapanel_access_data
from quantum_processor import run_simons_audit, get_rigetti_telemetry

DB_FILE = "completed_tasks.json"
RED_COLOR, BOLD, RESET_COLOR = "\033[91m", "\033[1m", "\033[0m"

def save_to_ledger(log_file, backend, signature, label, data_points):
    """Logs the audit findings to the JSON database."""
    counts = Counter(data_points)
    total = len(data_points)
    detailed_results = [{"identity": i, "percentage": f"{(c/total)*100:.2f}%", "count": c} for i, c in counts.most_common(10)]
    timestamp_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    task_hash = hashlib.md5(f"{timestamp_str}{log_file}".encode()).hexdigest()[:8].upper()
    new_entry = {"task_id": f"QS-{task_hash}", "timestamp": timestamp_str, "target_file": log_file, "category": label, "qpu_backend": backend, "quantum_signature": signature, "detailed_findings": detailed_results}
    data = []
    if os.path.exists(DB_FILE):
        try:
            with open(DB_FILE, 'r') as f: data = json.load(f)
        except: data = []
    data.append(new_entry)
    with open(DB_FILE, 'w') as f: json.dump(data, f, indent=4)
    print(f"\n[DB] Audit logged successfully to {DB_FILE}")

def show_ledger():
    """Interactive historical record viewer."""
    if not os.path.exists(DB_FILE):
        print("[!] No tasks recorded yet."); return
    with open(DB_FILE, 'r') as f: entries = json.load(f)
    choices = [f"[{e['task_id']}] {e['timestamp']} -> {e['target_file']}" for e in entries] + ["Back"]
    sel = questionary.select("Select record:", choices=choices).ask()
    if sel and sel != "Back":
        entry = next(e for e in entries if e['task_id'] in sel)
        print(f"\nSIGNATURE: {entry['quantum_signature']}\nFINDINGS:")
        for f in entry['detailed_findings']: print(f"{f['identity'][:30]:<30} | {f['percentage']} ({f['count']} hits)")

def show_setup_guide():
    """Terminal-based setup instructions."""
    os.system('clear')
    print(f"{BOLD}--- Q-SENTINEL AWS SETUP ---{RESET_COLOR}")
    print("1. Set IAM Policy: AmazonBraketFullAccess")
    print("2. Run: 'sudo aws configure' (Region: us-west-1)")
    print("3. Ensure Rigetti Cepheus-1 access is enabled in AWS Console.")
    
def main():
    os.system('clear')
    print("====================================================")
    print("   Q-SENTINEL: COST-EFFICIENT QPU AUDIT (v1.8.1)")
    print("====================================================")
    print(f"{RED_COLOR}{BOLD}REQUIREMENT: AWS CLI MUST BE SET TO 'us-west-1'{RESET_COLOR}\n")
    
    choice = questionary.select("Select Action:", choices=["0. QPU Telemetry", "1. SV1 Simulator", "2. Rigetti Cepheus-1", "3. View Ledger", "4. Setup Guide", "Exit"]).ask()
    if not choice or "Exit" in choice: sys.exit()
    if "0." in choice: get_rigetti_telemetry(); input("\nEnter..."); main(); return
    if "3." in choice: show_ledger(); input("\nEnter..."); main(); return
    if "4." in choice: show_setup_guide(); input("\nEnter..."); main(); return

    backend = "Cepheus" if "2." in choice else "SV1"
    audit_type = questionary.select("Category:", choices=["1. SSH (auth.log)", "2. aaPanel (access.log)", "Back"]).ask()
    if "Back" in audit_type: main(); return

    local_logs = [f for f in os.listdir('.') if f.endswith('.log')]
    log_options = (["SYSTEM: /www/wwwlogs/access.log"] if "2." in audit_type else ["SYSTEM: /var/log/auth.log"]) + local_logs
    selected_log = questionary.select("Select Source:", choices=log_options).ask()
    if "SYSTEM:" in selected_log: selected_log = selected_log.split(": ")[1]

    print(f"\n[!] Ingesting {selected_log} for {backend} processing...")
    data_points = extract_aapanel_access_data(selected_log) if "2." in audit_type else extract_all_unauthorized_attempts(selected_log)
    
    if not data_points:
        print("[X] Access Error. Use 'sudo' for SYSTEM paths."); input("\nEnter..."); main(); return

    sig = run_simons_audit(data_points, simulator_type=backend)
    
    counts = Counter(data_points)
    total = len(data_points)
    label = "IDENTIFIED PATTERN"
    print("\n" + "="*65)
    print(f"{label:<35} | {'ATTEMPT %':<15}")
    print("-" * 65)
    for item, count in counts.most_common(10):
        print(f"{item[:34]:<35} | {(count/total)*100:>8.2f}%")
    print("="*65)

    print(f"[SUCCESS] Quantum Signature: {sig}")
    save_to_ledger(selected_log, backend, sig, "THREAT", data_points)
    input("\nAudit Complete. Enter to return..."); main()

if __name__ == "__main__":
    main()
    
    