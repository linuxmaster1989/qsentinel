import re
from collections import Counter

def extract_all_unauthorized_attempts(file_path):
    all_names = []
    # Pattern for auth.log (SSH)
    pattern = re.compile(r"(?:Invalid user|Failed password for(?: invalid user)?) ([^\s]+) from")
    
    try:
        with open(file_path, 'r') as f:
            for line in f:
                match = pattern.search(line)
                if match:
                    all_names.append(match.group(1).strip())
    except FileNotFoundError:
        return None
    return all_names

def extract_aapanel_access_data(file_path):
    """
    Specifically parses aaPanel access logs to find 
    malicious activity signatures.
    """
    access_signatures = []
    # Regex to grab the IP, the Request Path, and the Status Code
    # Format: 192.168.1.1 - - [Date] "GET /path HTTP/1.1" 404 ...
    pattern = re.compile(r'(\d+\.\d+\.\d+\.\d+) - - .*?"\w+ (.*?) HTTP/.*?" (\d+)')
    
    try:
        with open(file_path, 'r') as f:
            for line in f:
                match = pattern.search(line)
                if match:
                    ip, path, status = match.groups()
                    # We focus on 4xx errors (client errors/scanning) as threats
                    if status.startswith('4'):
                        # We use the path as the unique 'feature' for Simon's Algorithm
                        access_signatures.append(path)
    except FileNotFoundError:
        return None
    return access_signatures
    