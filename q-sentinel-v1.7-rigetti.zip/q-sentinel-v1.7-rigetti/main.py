import questionary
import os
import sys
import json
import hashlib
from datetime import datetime
from collections import Counter
from log_parser import extract_all_unauthorized_attempts, extract_aapanel_access_data
from quantum_processor import run_simons_audit, get_rigetti_telemetry

DB_FILE = "completed_tasks.json"

# ANSI escape codes for professional terminal styling
RED_COLOR = "\033[91m"
BOLD = "\033[1m"
RESET_COLOR = "\033[0m"

def save_to_ledger(log_file, backend, signature, label, data_points):
    """
    Saves completed audit details to a JSON database including 
    the English names, percentages, counts, and a unique Task ID.
    """
    counts = Counter(data_points)
    total = len(data_points)
    
    detailed_results = []
    for item, count in counts.most_common(10):
        percentage = (count / total) * 100
        detailed_results.append({
            "identity": item,
            "percentage": f"{percentage:.2f}%",
            "count": count
        })

    timestamp_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    task_hash = hashlib.md5(f"{timestamp_str}{log_file}".encode()).hexdigest()[:8].upper()

    new_entry = {
        "task_id": f"QS-{task_hash}",
        "timestamp": timestamp_str,
        "target_file": log_file,
        "category": label,
        "qpu_backend": backend,
        "quantum_signature": signature,
        "detailed_findings": detailed_results
    }
    
    data = []
    if os.path.exists(DB_FILE):
        try:
            with open(DB_FILE, 'r') as f:
                data = json.load(f)
        except:
            data = []
            
    data.append(new_entry)
    with open(DB_FILE, 'w') as f:
        json.dump(data, f, indent=4)
    print(f"\n[DB] Audit logged successfully to {DB_FILE}")

def main():
    os.system('clear')
    print("====================================================")
    print("   Q-SENTINEL: COST-EFFICIENT QPU AUDIT")
    print("   TARGET: UBUNTU / AAPANEL ECOSYSTEM")
    print("====================================================")
    # Professional, bold red warning statement
    print(f"{RED_COLOR}{BOLD}CRITICAL SETUP REQUIREMENT:{RESET_COLOR}")
    print(f"{RED_COLOR}AWS CLI AND VALID AMAZON BRAKET API KEYS MUST BE FULLY{RESET_COLOR}")
    print(f"{RED_COLOR}CONFIGURED ON THIS SYSTEM TO ROUTE QUANTUM WORKLOADS.{RESET_COLOR}")
    print("====================================================\n")
    
    # 1. Main Menu
    choice = questionary.select(
        "Select Processing Unit:",
        choices=[
            "0. QPU Telemetry (Check Rigetti Status)",
            "1. AWS Braket SV1 Simulator",
            "2. Rigetti Cepheus-1 (108-Qubit QPU)",
            "3. View Completed Task Ledger",
            "4. AWS Quantum Setup Guide",
            "Exit"
        ]
    ).ask()

    if not choice or "Exit" in choice:
        sys.exit()

    # Handle Telemetry Selection
    if "Telemetry" in choice:
        get_rigetti_telemetry()
        input("\nPress Enter to return to main menu...")
        main()
        return

    # Handle Interactive Database View Selection
    if "Ledger" in choice:
        if os.path.exists(DB_FILE):
            try:
                with open(DB_FILE, 'r') as f:
                    entries = json.load(f)
            except Exception as e:
                print(f"[X] Database Error: Could not parse json. {e}")
                entries = []

            if entries:
                os.system('clear')
                print("====================================================")
                print("          Q-SENTINEL: HISTORICAL LEDGER             ")
                print("====================================================\n")
                
                menu_choices = []
                entry_map = {}
                
                for entry in entries:
                    tid = entry.get("task_id", "QS-LEGACY")
                    ts = entry.get("timestamp", "Unknown Time")
                    tf = entry.get("target_file", "Unknown Log")
                    
                    display_string = f"[{tid}] {ts} -> File: {tf}"
                    menu_choices.append(display_string)
                    entry_map[display_string] = entry
                
                menu_choices.append("Back to Main Menu")

                selected_run = questionary.select(
                    "Select an audit record to inspect detailed telemetry:",
                    choices=menu_choices
                ).ask()

                if selected_run and selected_run != "Back to Main Menu":
                    os.system('clear')
                    matched_data = entry_map[selected_run]
                    
                    print("====================================================")
                    print(f"       AUDIT REPORT: {matched_data.get('task_id', 'QS-LEGACY')}")
                    print("====================================================")
                    print(f"TIMESTAMP:         {matched_data.get('timestamp')}")
                    print(f"TARGET LOG:        {matched_data.get('target_file')}")
                    print(f"AUDIT TYPE:        {matched_data.get('category')}")
                    print(f"BACKEND USED:      {matched_data.get('qpu_backend')}")
                    print(f"QUANTUM SIGNATURE: {matched_data.get('quantum_signature')}")
                    print("----------------------------------------------------")
                    print(f"{'IDENTIFIED PATTERN / PATH':<35} | {'METRICS':<15}")
                    print("----------------------------------------------------")
                    
                    for finding in matched_data.get("detailed_findings", []):
                        ident = finding.get("identity", "")
                        pct = finding.get("percentage", "")
                        cnt = finding.get("count", 0)
                        print(f"{ident[:34]:<35} | {pct:>6} ({cnt} hits)")
                        
                    print("====================================================")
            else:
                print("[!] Ledger database file is empty.")
        else:
            print("[!] No tasks recorded yet.")
            
        input("\nPress Enter to return to main menu...")
        main()
        return

    # Handle Setup Guide Selection
    if "Setup Guide" in choice:
        os.system('clear')
        print("==============================================================")
        print("              AWS AMAZON BRAKET: QPU SETUP GUIDE              ")
        print("==============================================================")
        print(f"\n{BOLD}[ENVIRONMENT COMPATIBILITY NOTICE]{RESET_COLOR}")
        print("  - Target Environments: Ubuntu 22.04+, Kali Linux, Android (Termux)")
        print("  - Mobile Access Clients: Verified on JuiceSSH and Termius")
        print("  - Unverified Platforms: CentOS, RedHat, macOS, iOS")
        print("--------------------------------------------------------------")
        print(f"\n{BOLD}STEP 1: ENABLE AMAZON BRAKET{RESET_COLOR}")
        print("  - Log into your AWS Console (https://aws.amazon.com).")
        print("  - Search for 'Amazon Braket' in the top search bar.")
        print("  - Accept the service terms to initialize the Quantum environment.")
        print(f"\n{BOLD}STEP 2: GENERATE IAM API SECURITY KEYS{RESET_COLOR}")
        print("  - Open AWS IAM (Identity and Access Management).")
        print("  - Create a new User and attach the policy: 'AmazonBraketFullAccess'.")
        print("  - Select the user -> 'Security Credentials' -> 'Create Access Key'.")
        print("  - Choose 'Command Line Interface (CLI)' and download your")
        print("    Access Key ID and Secret Access Key.")
        print(f"\n{BOLD}STEP 3: LOCAL TERMINAL PIPELINE CONFIGURATION{RESET_COLOR}")
        print("  - Open your terminal and install the deployment prerequisites:")
        print("    $ sudo apt update && sudo apt install awscli python3-pip")
        print("  - Bind your API keys to the system runtime framework:")
        print("    $ aws configure")
        print("  - Enter your Access Key and Secret Key when prompted.")
        print("  - Set Default Region Name: us-west-1 (Required for Rigetti QPU)")
        print("  - Set Default Output Format: json")
        print(f"\n{BOLD}STEP 4: ANDROID MOBILE ENVIRONMENT PROVISIONING{RESET_COLOR}")
        print("  - Install Termux on your Android device.")
        print("  - Initialize the shell: pkg install python python-pip clang")
        print("  - Install the CLI tools locally: pip install awscli")
        print("  - Run 'aws configure' exactly as detailed in Step 3.")
        print("  - Securely manage and launch audits via mobile SSH using JuiceSSH")
        print("    or Termius to preserve native text layouts over remote sockets.")
        print("==============================================================")
        
        input("\nSetup Guide Complete. Press Enter to return to main menu...")
        main()
        return

    backend = "Cepheus" if "Cepheus" in choice else "SV1"

    # 2. Select Audit Type
    audit_type = questionary.select(
        "Select Audit Category:",
        choices=[
            "1. SSH Authentication Log (auth.log)",
            "2. aaPanel Access Log (access.log)",
            "Back"
        ]
    ).ask()

    if "Back" in audit_type:
        main()
        return

    # 3. Log Selection
    log_files = [f for f in os.listdir('.') if f.endswith('.log')]
    selected_log = questionary.select(
        "Select specific file for Quantum Audit:",
        choices=log_files if log_files else ["auth.log", "access.log"]
    ).ask()

    print(f"\n[!] Preparing {backend} for {selected_log} ingestion...")
    
    # 4. Data Extraction
    if "aaPanel" in audit_type:
        data_points = extract_aapanel_access_data(selected_log)
        label = "TARGETED PATH / EXPLOIT"
    else:
        data_points = extract_all_unauthorized_attempts(selected_log)
        label = "UNAUTHORIZED USERNAME"
    
    if not data_points:
        print(f"[X] Data Error: No valid threat patterns found in {selected_log}.")
        input("\nPress Enter to return...")
        main()
        return

    # 5. Execute Quantum Algorithm
    signature = run_simons_audit(data_points, simulator_type=backend)
    
    # 6. Results Display
    counts = Counter(data_points)
    total = len(data_points)

    print("\n" + "="*65)
    print(f"{label:<35} | {'ATTEMPT %':<15}")
    print("-" * 65)

    for item, count in counts.most_common(10):
        percentage = (count / total) * 100
        print(f"{item[:34]:<35} | {percentage:>8.2f}%")

    print("="*65)
    print(f"[SUCCESS] Quantum Signature Identified: {signature}")
    print(f"[INFO] Analysis completed on {backend}.")
    
    # 7. Save the task to the database
    save_to_ledger(selected_log, backend, signature, label, data_points)
    
    input("\nAudit Complete. Press Enter to return to menu...")
    main()

if __name__ == "__main__":
    main()
    