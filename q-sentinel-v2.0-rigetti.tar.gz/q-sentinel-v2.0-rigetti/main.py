import questionary
import os
import sys
import json
import hashlib
from datetime import datetime
from collections import Counter
from log_parser import (
    extract_all_unauthorized_attempts, 
    extract_aapanel_access_data, 
    run_threat_intelligence_lookup
)
from quantum_processor import run_simons_audit, get_rigetti_telemetry

DB_FILE = "completed_tasks.json"

def save_to_ledger(log_file, backend, signature, label, data_points):
    """Saves telemetry analysis structures down to local tracking database ledger."""
    counts = Counter(data_points)
    total = len(data_points)
    detailed_results = [{"identity": i, "percentage": f"{(c/total)*100:.2f}%", "count": c} for i, c in counts.most_common(10)]
    timestamp_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    task_hash = hashlib.md5(f"{timestamp_str}{log_file}".encode()).hexdigest()[:8].upper()
    
    new_entry = {
        "task_id": f"QS-{task_hash}",
        "timestamp": timestamp_str,
        "target_file": log_file,
        "category": label,
        "qpu_backend": backend,
        "quantum_signature": signature,
        "detailed_findings": detailed_results
    }
    
    data = []
    if os.path.exists(DB_FILE):
        try:
            with open(DB_FILE, 'r') as f:
                data = json.load(f)
        except json.JSONDecodeError:
            data = []
            
    data.append(new_entry)
    with open(DB_FILE, 'w') as f:
        json.dump(data, f, indent=4)

def open_threat_intelligence_hub():
    """Parses previous historical entries based on chosen log branch type."""
    if not os.path.exists(DB_FILE):
        print("\n[X] No historical database tracking ledger found. Run an audit first!")
        return

    try:
        with open(DB_FILE, 'r') as f:
            entries = json.load(f)
    except Exception:
        print("\n[X] Tracking ledger corrupted or unreadable.")
        return

    if not entries:
        print("\n[X] Threat ledger database is currently empty.")
        return

    # Branching Step: Select which log source context to inspect
    hub_branch = questionary.select(
        "Select Threat Intelligence Source Context:",
        choices=[
            "1. SSH (auth.log) Historic Identities",
            "2. aaPanel (access.log) Flagged IPs",
            "<= Return to Main Menu"
        ]
    ).ask()

    if hub_branch == "<= Return to Main Menu" or not hub_branch:
        return

    # Target file mapping based on selection
    target_log_filter = "auth.log" if "1." in hub_branch else "access.log"
    
    # Scan the JSON history file and filter unique identities belonging ONLY to that target_file
    valid_targets = {}
    for entry in reversed(entries):
        if entry.get("target_file") == target_log_filter:
            for finding in entry.get("detailed_findings", []):
                identity = finding.get("identity", "")
                
                # Double-check constraints to match target structures nicely
                if identity and identity not in valid_targets:
                    # Formulate display based on log nature
                    if target_log_filter == "auth.log":
                        # Could be username strings or malicious IP targets depending on log state
                        valid_targets[identity] = f"Hits: {finding.get('count')} (Last Swept: {entry.get('timestamp')})"
                    else:
                        # Pure web server IPs
                        valid_targets[identity] = f"Scans: {finding.get('count')} (Last Swept: {entry.get('timestamp')})"

    if not valid_targets:
        print(f"\n[!] No active logs found in historic ledger entries for: {target_log_filter}")
        return

    # Construct the selectable menu choices array out of the filtered ledger entries
    menu_label = "Select Flagged SSH Entry for Deep Threat Audit:" if target_log_filter == "auth.log" else "Select Target Flagged Web IP for Deep DNS Threat Audit:"
    choices = [f"{identity} ({desc})" for identity, desc in valid_targets.items()] + ["<= Return to Hub Menu"]
    
    selected_choice = questionary.select(
        menu_label,
        choices=choices
    ).ask()

    if selected_choice == "<= Return to Hub Menu" or not selected_choice:
        # Loop back into the hub menu for easy cross-referencing
        open_threat_intelligence_hub()
        return

    # Extract the pure identity string out of the option line
    target_identity = selected_choice.split(" ")[0]
    
    # Fire off lookup system (intelligent enough to ignore non-IP names gracefully)
    run_threat_intelligence_lookup(target_identity)

def main():
    print("\n====================================================")
    print("   Q-SENTINEL: COST-EFFICIENT QPU AUDIT (v1.8.3)   ")
    print("====================================================")
    print("REQUIREMENT: AWS CLI MUST BE SET TO 'us-west-1'")
    
    choice = questionary.select(
        "Select Action:",
        choices=["0. QPU Telemetry", "1. SV1 Simulator", "2. Cepheus-1 QPU", "3. Threat Intelligence Hub", "Exit"]
    ).ask()

    if choice == "Exit" or not choice:
        sys.exit(0)

    if "0." in choice:
        get_rigetti_telemetry()
        input("\nEnter...")
        main()
        return

    if "3." in choice:
        open_threat_intelligence_hub()
        input("\nEnter...")
        main()
        return

    backend = "Cepheus" if "2." in choice else "SV1"
    audit_type = questionary.select("Category:", choices=["1. SSH (auth.log)", "2. aaPanel (access.log)", "Back"]).ask()
    if "Back" in audit_type or not audit_type:
        main()
        return

    selected_log = "auth.log" if "1." in audit_type else "access.log"

    print(f"\n[!] Parsing local directory file context ({selected_log}) for {backend} distribution...")
    
    if "1." in audit_type:
        data_points = extract_all_unauthorized_attempts(selected_log)
    else:
        data_points = extract_aapanel_access_data(selected_log)
    
    if not data_points:
        print("[X] Execution halted due to empty data context structure.")
        input("\nEnter..."); main(); return

    sig = run_simons_audit(data_points, simulator_type=backend)
    
    counts = Counter(data_points)
    total = len(data_points)
    print("\n" + "="*65)
    print(f"{'IDENTIFIED PATTERN':<35} | {'ATTEMPT %':<15}")
    print("-" * 65)
    for item, count in counts.most_common(10):
        pct = (count / total) * 100
        print(f"{item:<35} | {pct:.2f}% ({count} entries)")
    print("-" * 65)
    print(f"QUANTUM SIGNATURE PATTERN INTERCEPTED: {sig}")
    print("="*65)

    save_to_ledger(selected_log, backend, sig, "THREAT", data_points)
    print("[OK] Session results saved into completed_tasks.json ledger.")
    input("\nEnter...")
    main()

if __name__ == "__main__":
    main()
    